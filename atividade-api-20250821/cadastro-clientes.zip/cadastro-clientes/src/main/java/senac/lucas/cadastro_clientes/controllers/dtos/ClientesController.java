package senac.lucas.cadastro_clientes.controllers.dtos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import senac.lucas.cadastro_clientes.entity.Cliente;
import senac.lucas.cadastro_clientes.services.ClientesService;

import java.util.List;

@Controller
@RequestMapping("/clientes")
public class ClientesController {

    @Autowired
    private ClientesService clientesService;

    @PostMapping("/criar")
    public ResponseEntity<Cliente> criar(@RequestBody ClienteCreateDTO clienteDto){
        try{
            return ResponseEntity.ok(clientesService.criar(clienteDto));
        }catch (Exception e){
            e.printStackTrace();
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/listar")
    public ResponseEntity<List<Cliente>> listar() {
            List<Cliente> clientes = clientesService.listar();
            return ResponseEntity.ok(clientes);
    }

    @PutMapping("atualizar/{id}")
    public ResponseEntity<Cliente> atualizar(@PathVariable Long id,
                                             @RequestBody ClienteCreateDTO cliente)
    {
        return ResponseEntity.ok(clientesService.atualizar(id, cliente));
    }

    @DeleteMapping("excluir/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id){
        try {
            clientesService.excluir(id);
            return ResponseEntity.ok(null);
        }catch (Exception e){
            e.printStackTrace();
            return ResponseEntity.badRequest().body(null);
        }
    }
}
