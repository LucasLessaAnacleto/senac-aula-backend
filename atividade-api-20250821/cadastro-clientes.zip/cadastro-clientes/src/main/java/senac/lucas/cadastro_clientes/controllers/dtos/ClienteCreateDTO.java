package senac.lucas.cadastro_clientes.controllers.dtos;


import senac.lucas.cadastro_clientes.entity.Cliente;

import java.time.LocalDate;
import java.time.Period;

public class ClienteCreateDTO {

    private String nome ;
    private String sobrenome;
    private String documento;
    private String email;
    private LocalDate dataNascimento;
    private int ddd;
    private int telefone;
    private int idade;
    private String sexo;

    public ClienteCreateDTO(String sexo, int telefone, int ddd, LocalDate dataNascimento, String email, String documento, String nomeCompleto) throws Exception {
        String[] nomeSplit = nomeCompleto.split("\s", 2);
        System.out.println(nomeSplit[0]);
        if( nomeSplit.length < 2 ) throw new Exception("Nome completo inadequado");
        this.nome = nomeSplit[0];
        this.sobrenome = nomeSplit[1];
        if (email == null) throw new Exception("Email deve ser informado");
        this.email = email;
        if (documento == null) throw new Exception("Documento deve ser informado");
        this.documento = documento;


        this.sexo = sexo;
        if(dataNascimento != null){
            LocalDate hoje = LocalDate.now();
            this.idade = Period.between(dataNascimento, hoje).getYears();

        }
        this.telefone = telefone;
        this.ddd = ddd;
        this.dataNascimento = dataNascimento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public int getDdd() {
        return ddd;
    }

    public void setDdd(int ddd) {
        this.ddd = ddd;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Cliente mapear() {
        Cliente cliente = new Cliente();
        cliente.setNome( this.getNome() );
        cliente.setSobrenome( this.getSobrenome() );
        cliente.setDocumento( this.getDocumento() );

        cliente.setEmail( this.getEmail() );
        cliente.setIdade( this.getIdade() );
        cliente.setDdd( this.getDdd() );
        cliente.setDataNascimento( this.getDataNascimento() );

        return cliente;
    }

}
