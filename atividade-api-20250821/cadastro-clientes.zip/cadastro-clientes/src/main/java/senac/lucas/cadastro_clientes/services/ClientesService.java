package senac.lucas.cadastro_clientes.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import senac.lucas.cadastro_clientes.controllers.dtos.ClienteCreateDTO;
import senac.lucas.cadastro_clientes.entity.Cliente;
import senac.lucas.cadastro_clientes.repository.ClientesRepository;

import java.util.List;

@Service
public class ClientesService {

    @Autowired
    private ClientesRepository clientesRepository;

    public Cliente criar(ClienteCreateDTO clienteDto) {
        Cliente clientePersist = clienteDto.mapear();
        clientesRepository.save(clientePersist);
        return clientePersist;
    }

    public List<Cliente> listar() {
        try{
            List<Cliente> clienteQuery = clientesRepository.findAll();
            return clienteQuery;
        }catch (Exception e){
            e.printStackTrace();
            return List.of();
        }
    }

    public Cliente atualizar(Long id, ClienteCreateDTO cliente){
        try{
            Cliente clienteBody = cliente.mapear();
            clienteBody.setId(id);
            Cliente clienteAtualizado = clientesRepository.save(clienteBody);
            return clienteAtualizado;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void excluir(Long id) {
        clientesRepository.deleteById(id);
        return;
    }
}
